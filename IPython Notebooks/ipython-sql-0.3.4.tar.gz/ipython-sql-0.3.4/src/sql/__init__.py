from .magic import *
